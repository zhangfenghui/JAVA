package org.eclipse.wb.swing;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Panel;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;

import javax.annotation.processing.SupportedAnnotationTypes;
import javax.management.remote.SubjectDelegationPermission;

public class mypanel extends Panel {
	private Graphics g;
	private Image image;
	private Image logo=null;
    public void paint(Graphics g) {
    	this.g=g;
    	super.paint(this.g);
        draw(this.g);
        	
    }
    private void draw(Graphics g)
    {
    	g.drawImage(this.image, 0, 0, null);
        int a=this.image.getWidth(null)>this.image.getHeight(null)?this.image.getWidth(null):this.image.getHeight(null);
        a=(a/3);
        if(logo!=null)
        { 
        	g.setColor(Color.WHITE);
        	g.fillRect(a+5, a+5, a-10, a-10);
        	g.drawImage(logo, a+5, a+5, a-10, a-10, null);
        }
    }
    public void setImage(Image image)
    {
    	this.image=image;
    	super.repaint();
    }
    public void setLogo(Image logo)
    {
    	this.logo=logo;
    	super.repaint();
    }
    public BufferedImage getImage()
    {
    	BufferedImage pict_show=new BufferedImage(this.image.getWidth(null), this.image.getHeight(null), Image.SCALE_SMOOTH);
    	Graphics s=pict_show.createGraphics();
    	draw(s);
    	return pict_show;
    }

}
