package lib;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import javax.imageio.ImageIO;
import com.google.zxing.*;
import com.google.zxing.client.j2se.*;
import com.google.zxing.common.*;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

public class Zxing {
	private BufferedImage image;
	private String text;
	private int width;
	private int height;
	private  Comparable jibian;
	private String path;
	private Result result;
	
     public BufferedImage getImage() {
		return this.image;
	}
	public void setImage(BufferedImage image) {
		this.image = image;
		readTwocode();
	}
	public String getText() {
		return this.result.getText();
	}
	public void setText(String text) {
		this.text = text;
		makeTwocode();
	}
	public int getWidth() {
		return this.image.getWidth();
	}
	public void setWidth(int width) {	
		this.width = width;
		makeTwocode();
	}
	public int getHeight() {
		return this.image.getHeight();
	}
	public void setHeight(int height) {
		this.height = height;
		makeTwocode();
	}
	public void setPath(String path) {
		this.path = path;
		readTwocode();
	}
	 Zxing(String text,int width,int height,char dengji) {
         switch (dengji) {
		     case 'Q': this.jibian=ErrorCorrectionLevel.Q;break;
		     case 'H':this.jibian=ErrorCorrectionLevel.H;break;
		     case 'L':this.jibian=ErrorCorrectionLevel.L;break;
		     case 'M':this.jibian=ErrorCorrectionLevel.M;break;
		   }
         this.text=text;
         this.width=width;
         this.height=height;
         makeTwocode();
            
  }
     private void  makeTwocode() {
    	 BitMatrix bitMatrix = null;
    	 HashMap<EncodeHintType, Comparable> hints=new HashMap<EncodeHintType, Comparable>();
         hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
         hints.put(EncodeHintType.ERROR_CORRECTION,this.jibian);
         hints.put(EncodeHintType.MARGIN, 2);         
 	    try {
 		  bitMatrix = new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, this.width, this.height,hints);
 		 this.image= MatrixToImageWriter.toBufferedImage(bitMatrix);
 	      } catch (WriterException e) {
 		// TODO �Զ����ɵ� catch ��
 		    e.printStackTrace();
 	      }   	
	}
     //������ȡ��ά��
      Zxing(String path){
    	  try {
			image = ImageIO.read(new File(this.path));	
		    } catch (IOException e) {
			    e.printStackTrace();
		  }
    	  readTwocode();
	}
      Zxing(BufferedImage image) {
    	 this.image=image;
    	 readTwocode();
		// TODO �Զ����ɵĹ��캯�����
	}
     Zxing(File file) {
		try {
			this.image=ImageIO.read(file);	
	    } catch (IOException e) {
		    e.printStackTrace();
	  }
		readTwocode();
	}
     private void readTwocode(){
    	 
    	 HashMap mymaps=new HashMap();
    	 mymaps.put(EncodeHintType.CHARACTER_SET, "utf-8");
    	 MultiFormatReader formatReader = new MultiFormatReader();
    	 BinaryBitmap binaryBitmap=new  BinaryBitmap(new HybridBinarizer(new BufferedImageLuminanceSource(this.image)));  
		try {
			 this.result=formatReader.decode(binaryBitmap,mymaps);
		} catch (NotFoundException e) {
			e.printStackTrace();
		} 
     }
     public Result getResult()
     {
		return this.result;
     }
}
