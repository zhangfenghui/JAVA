package lib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.Format;

import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.eclipse.wb.swing.mypanel;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import java.awt.Font;
public class Twocode extends JFrame {
	private JTextField K_width;
	private JTextField K_height;
	private JComboBox comboBox;
	private JTextField mytext;
	private String format;
	private String mypath;
	private BufferedImage imagebuf=null;
	 private BufferedImage imagesave=null;
	private BufferedImage show_picture_buf=null;
	private BufferedImage Twocodelogo;
	private JTextField read_twocode;
	private JTextField filename;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Twocode frame = new Twocode();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
   
	public Twocode() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 600);		
		 JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		  Container container = this.getLayeredPane();
		  JPanel combop = new JPanel();
		  JPanel about = new  JPanel();
		  String lable[]={"H","L","M","Q"};
		  JPanel make = new JPanel();
		  mypanel picture=new mypanel();
		  picture.setBounds(0,150,0,0);
		  JLabel label_2 = new JLabel("�����ȼ���");
		  comboBox = new JComboBox(lable);
		  
		  make.setBackground(Color.WHITE);
		  make.setForeground(Color.WHITE);
		  JLabel label = new JLabel("���ȣ�");
		  JLabel label_1 = new JLabel("�߶ȣ�");
		  K_width = new JTextField();
		  K_height = new JTextField();
		  tabbedPane.add("���ɶ�ά��",make);
		  
		  K_width.addKeyListener(new KeyAdapter() {
		  	@Override
		  	public void keyTyped(KeyEvent e) {
		  		int keyChar=e.getKeyChar();
		  		if (keyChar>=KeyEvent.VK_0 && keyChar<=KeyEvent.VK_9) {

		  		} else {
		  		e.consume(); 
		  		}
		  	}
		  });
		  
		  
		  
		  
		  K_width.setColumns(10);
		  
		  
		  K_height.addKeyListener(new KeyAdapter() {
		  	@Override
		  	public void keyTyped(KeyEvent e) {
		  		int keyChar=e.getKeyChar();
		  		if (keyChar>=KeyEvent.VK_0 && keyChar<=KeyEvent.VK_9) {

		  		} else {
		  		e.consume(); 
		  		}
		  	}
		  });
		  K_height.setColumns(10);
		  
		  
		  comboBox.setLightWeightPopupEnabled(false);
		  
		  JLabel label_3 = new JLabel("\u5185\u5BB9:");
		  JButton button = new JButton("\u751F\u6210");
		  button.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		if(mytext.getText().isEmpty()||K_width.getText().isEmpty()||K_height.getText().isEmpty())
		  		{
		  			JOptionPane.showMessageDialog(null, "���벻��Ϊ��", "�������", 1);
		  			return;
		  		}
		  		char []a=lable[comboBox.getSelectedIndex()].toCharArray();
		  		Zxing myZxing=new Zxing(new String(mytext.getText()),new Integer(K_width.getText()).intValue(),new Integer(K_height.getText()).intValue(),a[0]);
		  		imagebuf=myZxing.getImage();
		  		picture.setSize(imagebuf.getWidth(),imagebuf.getHeight());
		  		picture.setImage(imagebuf);
		  	}
		  });
		  
		  mytext = new JTextField();
		  mytext.setColumns(10);
		  Frame []frame=this.getFrames();
		  JButton button_1 = new JButton("\u4FDD\u5B58");
		  button_1.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {		  		
		  		if(imagebuf==null)
		  		{
		  			JOptionPane.showMessageDialog(null, "û�п��Ա�����ļ�", "�������", 1);
		  			return;
		  		}
		  		imagesave=picture.getImage();
		  		 JFileChooser chooser=new JFileChooser();
		  		FileNameExtensionFilter file1=new FileNameExtensionFilter("jpg","jpg");
		  		FileNameExtensionFilter file2=new FileNameExtensionFilter("png","png");
		  		FileNameExtensionFilter file3=new FileNameExtensionFilter("bmp","bmp");
		  		FileNameExtensionFilter file4=new FileNameExtensionFilter("jpeg","jpeg");
		  		 chooser.setFileFilter(file1);
		  		 chooser.setFileFilter(file2);
		  		 chooser.setFileFilter(file3);
		  		 chooser.setFileFilter(file4);
		  		 int returnavl=chooser.showSaveDialog(frame[0]);
		  		 if(returnavl==chooser.APPROVE_OPTION)
		  		 {
		  			 String format=chooser.getFileFilter().getDescription();	  			 	 
		  			 
		  			mypath=chooser.getSelectedFile().getAbsolutePath();
					
		  			if(format.toString().endsWith("�����ļ�"))
		  			{
		  				String []buf=mypath.split("\\.");
		  				System.out.println(buf[0]);
		  				if(buf.length==2)
		  				  format=buf[1];
		  				else
		  				{
		  				  format="png";
		  				 mypath=mypath+"."+format;
		  				}		
		  			}else{
		  				mypath=mypath+"."+format;
		  			}
		  			try {
						ImageIO.write(imagesave,format,new File(mypath));
					 } catch (IOException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					 }
		  		 }
		  	}
		  });  
		  
		  JButton btnNewButton = new JButton("\u52A0\u5165LOGO");
		  btnNewButton.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		if(imagebuf==null)
		  		{
		  			JOptionPane.showMessageDialog(null, "û�ж�ά�룬��������", "�������", 1);
		  			return;
		  		}
		  		JFileChooser openfilelogo=new JFileChooser();
			  	 FileNameExtensionFilter file1=new FileNameExtensionFilter("jpg","jpg");
		  		 FileNameExtensionFilter file2=new FileNameExtensionFilter("png","png");
		  		 FileNameExtensionFilter file3=new FileNameExtensionFilter("bmp","bmp");
		  		 FileNameExtensionFilter file4=new FileNameExtensionFilter("jpeg","jpeg");
		  		openfilelogo.setFileFilter(file1);
		  		openfilelogo.setFileFilter(file2);
		  		openfilelogo.setFileFilter(file3);
		  		openfilelogo.setFileFilter(file4);
		  		 int returnval=openfilelogo.showOpenDialog(null);
		  		 if(returnval==openfilelogo.APPROVE_OPTION)
		  		 {	  			 
		  			try {
		  				Twocodelogo=ImageIO.read(openfilelogo.getSelectedFile());
					} catch (IOException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();	
					}
		  			
		  			picture.setLogo(Twocodelogo);
		  		 }
		  	}
		  });
		  
		  JButton btnlogo = new JButton("\u6E05\u9664LOGO");
		  btnlogo.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		picture.setLogo(null);
		  	}
		  });
		  GroupLayout gl_make = new GroupLayout(make);
		  gl_make.setHorizontalGroup(
		  	gl_make.createParallelGroup(Alignment.LEADING)
		  		.addGroup(gl_make.createSequentialGroup()
		  			.addGap(10)
		  			.addGroup(gl_make.createParallelGroup(Alignment.TRAILING, false)
		  				.addGroup(gl_make.createSequentialGroup()
		  					.addComponent(label)
		  					.addPreferredGap(ComponentPlacement.RELATED)
		  					.addComponent(K_width, GroupLayout.PREFERRED_SIZE, 56, GroupLayout.PREFERRED_SIZE)
		  					.addPreferredGap(ComponentPlacement.RELATED)
		  					.addComponent(label_1)
		  					.addPreferredGap(ComponentPlacement.RELATED)
		  					.addComponent(K_height, GroupLayout.PREFERRED_SIZE, 52, GroupLayout.PREFERRED_SIZE)
		  					.addGap(18)
		  					.addComponent(label_2))
		  				.addGroup(gl_make.createSequentialGroup()
		  					.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
		  					.addPreferredGap(ComponentPlacement.RELATED)
		  					.addComponent(mytext)
		  					.addGap(18)
		  					.addComponent(button)))
		  			.addGap(18)
		  			.addGroup(gl_make.createParallelGroup(Alignment.LEADING)
		  				.addComponent(btnlogo)
		  				.addGroup(gl_make.createParallelGroup(Alignment.LEADING, false)
		  					.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
		  					.addComponent(button_1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
		  					.addComponent(comboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
		  			.addContainerGap(54, Short.MAX_VALUE))
		  );
		  gl_make.setVerticalGroup(
		  	gl_make.createParallelGroup(Alignment.LEADING)
		  		.addGroup(gl_make.createSequentialGroup()
		  			.addGap(29)
		  			.addGroup(gl_make.createParallelGroup(Alignment.LEADING)
		  				.addGroup(gl_make.createSequentialGroup()
		  					.addGap(3)
		  					.addComponent(label))
		  				.addGroup(gl_make.createParallelGroup(Alignment.BASELINE)
		  					.addComponent(K_width, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
		  					.addComponent(label_1)
		  					.addComponent(K_height, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
		  					.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
		  					.addComponent(label_2)))
		  			.addGap(18)
		  			.addGroup(gl_make.createParallelGroup(Alignment.BASELINE, false)
		  				.addComponent(label_3, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
		  				.addComponent(mytext, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
		  				.addComponent(button)
		  				.addComponent(button_1))
		  			.addPreferredGap(ComponentPlacement.RELATED)
		  			.addComponent(btnNewButton)
		  			.addPreferredGap(ComponentPlacement.RELATED)
		  			.addComponent(btnlogo)
		  			.addContainerGap(118, Short.MAX_VALUE))
		  );
		  make.setLayout(gl_make);
		  make.add(picture);
		  JPanel shows = new  JPanel();
		  tabbedPane.add("�鿴��ά��",shows);
		  
		  JLabel label_4 = new JLabel("\u6587\u4EF6\u540D\uFF1A");
		  mypanel showpicture=new mypanel();
		  showpicture.setBounds(0, 100, 0, 0);
		  shows.add(showpicture);
		  JButton button_2 = new JButton("\u6253\u5F00");
		  button_2.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  	JFileChooser openfile=new JFileChooser();
		  	 FileNameExtensionFilter file1=new FileNameExtensionFilter("jpg","jpg");
	  		 FileNameExtensionFilter file2=new FileNameExtensionFilter("png","png");
	  		 FileNameExtensionFilter file3=new FileNameExtensionFilter("bmp","bmp");
	  		 FileNameExtensionFilter file4=new FileNameExtensionFilter("jpeg","jpeg");
	  		 openfile.setFileFilter(file1);
	  		 openfile.setFileFilter(file2);
	  		 openfile.setFileFilter(file3);
	  		 openfile.setFileFilter(file4);
	  		 int returnval=openfile.showOpenDialog(null);
	  		 if(returnval==openfile.APPROVE_OPTION)
	  		 {
	  			 String name=openfile.getSelectedFile().getName();
	  			 filename.setText(name);
	  			try {
					show_picture_buf=ImageIO.read(openfile.getSelectedFile());
				} catch (IOException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();	
				}
	  			showpicture.setBounds(0, 100, show_picture_buf.getWidth(), show_picture_buf.getHeight());
	  			showpicture.setImage(show_picture_buf);
	  			Zxing read_two=new Zxing(show_picture_buf);
	  			
	  			read_twocode.setText(read_two.getText());
	  			 
	  		 }
		  	}
		  });
		  
		  
		  
		  JLabel label_5 = new JLabel("\u8BFB\u53D6\u7ED3\u679C:");
		  
		  read_twocode = new JTextField();
		  read_twocode.setColumns(10);
		  
		  filename = new JTextField();
		  filename.setEditable(false);
		  filename.setColumns(30);
		  GroupLayout gl_shows = new GroupLayout(shows);
		  gl_shows.setHorizontalGroup(
		  	gl_shows.createParallelGroup(Alignment.LEADING)
		  		.addGroup(gl_shows.createSequentialGroup()
		  			.addContainerGap()
		  			.addGroup(gl_shows.createParallelGroup(Alignment.LEADING)
		  				.addComponent(label_5)
		  				.addComponent(label_4))
		  			.addPreferredGap(ComponentPlacement.RELATED)
		  			.addGroup(gl_shows.createParallelGroup(Alignment.TRAILING, false)
		  				.addComponent(filename)
		  				.addComponent(read_twocode, 271, 271, Short.MAX_VALUE))
		  			.addGap(24)
		  			.addComponent(button_2)
		  			.addContainerGap(25, Short.MAX_VALUE))
		  );
		  gl_shows.setVerticalGroup(
		  	gl_shows.createParallelGroup(Alignment.LEADING)
		  		.addGroup(gl_shows.createSequentialGroup()
		  			.addGap(21)
		  			.addGroup(gl_shows.createParallelGroup(Alignment.TRAILING)
		  				.addGroup(gl_shows.createParallelGroup(Alignment.BASELINE)
		  					.addComponent(button_2, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
		  					.addComponent(filename, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
		  				.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
		  			.addPreferredGap(ComponentPlacement.UNRELATED)
		  			.addGroup(gl_shows.createParallelGroup(Alignment.BASELINE)
		  				.addComponent(label_5)
		  				.addComponent(read_twocode, GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE))
		  			.addContainerGap(159, Short.MAX_VALUE))
		  );
		  
		  shows.setLayout(gl_shows);
		  tabbedPane.add("����",about );
		  
		  JLabel label_6 = new JLabel("1.\u672C\u4E8C\u7EF4\u7801\u751F\u6210\u67E5\u770B\u5DE5\u5177\u53EA\u7528\u4E8E\u5B66\u4E60\u4EA4\u6D41\u3002");
		  label_6.setFont(new Font("����", Font.PLAIN, 17));
		  
		  JLabel label_7 = new JLabel("2.\u751F\u6210\u65F6\u6CE8\u610F\u4E8C\u4F4D\u7801\u5C3A\u5BF8\uFF0C\u4E0D\u80FD\u65E0\u9650\u5927\u3002");
		  label_7.setFont(new Font("����", Font.PLAIN, 17));
		  
		  JLabel lbllogo = new JLabel("3.\u672C\u5DE5\u5177\u6709\u52A0\u5165\u4E8C\u7EF4\u7801LOGO\u7684\u529F\u80FD\u3002");
		  lbllogo.setFont(new Font("����", Font.PLAIN, 17));
		  GroupLayout gl_about = new GroupLayout(about);
		  gl_about.setHorizontalGroup(
		  	gl_about.createParallelGroup(Alignment.LEADING)
		  		.addGroup(gl_about.createSequentialGroup()
		  			.addGap(52)
		  			.addGroup(gl_about.createParallelGroup(Alignment.LEADING)
		  				.addComponent(lbllogo)
		  				.addComponent(label_7)
		  				.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 352, GroupLayout.PREFERRED_SIZE))
		  			.addContainerGap(41, Short.MAX_VALUE))
		  );
		  gl_about.setVerticalGroup(
		  	gl_about.createParallelGroup(Alignment.LEADING)
		  		.addGroup(gl_about.createSequentialGroup()
		  			.addGap(74)
		  			.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
		  			.addPreferredGap(ComponentPlacement.RELATED)
		  			.addComponent(label_7)
		  			.addGap(18)
		  			.addComponent(lbllogo)
		  			.addContainerGap(100, Short.MAX_VALUE))
		  );
		  about.setLayout(gl_about);

		  combop.add(new JLabel("��ά�����ɲ鿴����"));
		  
		  container.setLayout(new BorderLayout());
		  container.add(combop,BorderLayout.NORTH);
		  container.add(tabbedPane,BorderLayout.CENTER);
		
	}
}
